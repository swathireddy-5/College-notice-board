# College Notice Board 🎓

A complete, production-ready Flutter application built with **Dart** and **Material 3** for managing and browsing college announcements across departments.

## 🌟 Features
1. Notice list screen with ListView and Card widgets
2. Department FilterChips (All, CSE, ECE, EEE, Mechanical, Civil, Administration)
3. Notice detail screen with full description and delete confirmation dialog
4. Post notice form with Form validation (Title >= 5 chars, Description >= 10 chars, Dropdown, DatePicker)
5. Local data storage using shared_preferences and intl

## 🚀 How to Run
```bash
cd college_notice_board
flutter pub get
flutter run
```