import 'package:intl/intl.dart';

/// Data model representing an individual college announcement notice.
class Notice {
  final String id;
  final String title;
  final String description;
  final DateTime date;
  final String department;

  Notice({
    required this.id,
    required this.title,
    required this.description,
    required this.date,
    required this.department,
  });

  /// Formatted date string formatted as '05 Nov 2026'
  String get formattedDate {
    return DateFormat('dd MMM yyyy').format(date);
  }

  /// Converts Notice instance to a JSON Map for persistence
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'description': description,
      'date': date.toIso8601String(),
      'department': department,
    };
  }

  /// Creates a Notice instance from decoded JSON Map
  factory Notice.fromJson(Map<String, dynamic> json) {
    return Notice(
      id: json['id'] as String,
      title: json['title'] as String,
      description: json['description'] as String,
      date: DateTime.parse(json['date'] as String),
      department: json['department'] as String,
    );
  }

  /// Creates a copy of Notice with updated fields
  Notice copyWith({
    String? id,
    String? title,
    String? description,
    DateTime? date,
    String? department,
  }) {
    return Notice(
      id: id ?? this.id,
      title: title ?? this.title,
      description: description ?? this.description,
      date: date ?? this.date,
      department: department ?? this.department,
    );
  }
}