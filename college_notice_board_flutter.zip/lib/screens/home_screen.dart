import 'package:flutter/material.dart';
import '../models/notice.dart';
import '../services/storage_service.dart';
import 'detail_screen.dart';
import 'add_notice_screen.dart';

/// The main dashboard screen showing a scrollable list of notices,
/// department filter chips, and a floating action button to post notices.
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final StorageService _storageService = StorageService();

  // List of departments for filtering
  final List<String> _departments = [
    'All',
    'CSE',
    'ECE',
    'EEE',
    'Mechanical',
    'Civil',
    'Administration',
  ];

  String _selectedDepartment = 'All';
  List<Notice> _allNotices = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadNotices();
  }

  /// Loads notices from SharedPreferences storage
  Future<void> _loadNotices() async {
    setState(() => _isLoading = true);
    final loaded = await _storageService.loadNotices();
    setState(() {
      _allNotices = loaded;
      _isLoading = false;
    });
  }

  /// Filters notices based on the currently selected department chip
  List<Notice> get _filteredNotices {
    if (_selectedDepartment == 'All') {
      return _allNotices;
    }
    return _allNotices
        .where((n) => n.department.toLowerCase() == _selectedDepartment.toLowerCase())
        .toList();
  }

  /// Returns a distinctive color scheme for each college department
  Color _getDepartmentColor(String dept) {
    switch (dept.toUpperCase()) {
      case 'CSE':
        return Colors.blue.shade700;
      case 'ECE':
        return Colors.deepPurple.shade600;
      case 'EEE':
        return Colors.orange.shade800;
      case 'MECHANICAL':
        return Colors.teal.shade700;
      case 'CIVIL':
        return Colors.green.shade700;
      case 'ADMINISTRATION':
        return Colors.indigo.shade700;
      default:
        return Colors.blueGrey.shade700;
    }
  }

  /// Navigates to the Add Notice screen and refreshes list on success
  Future<void> _navigateToAddNotice() async {
    final result = await Navigator.push<bool>(
      context,
      MaterialPageRoute(builder: (context) => const AddNoticeScreen()),
    );

    if (result == true) {
      _loadNotices();
    }
  }

  /// Navigates to the Notice Detail screen and refreshes list if deleted
  Future<void> _navigateToDetail(Notice notice) async {
    final result = await Navigator.push<bool>(
      context,
      MaterialPageRoute(
        builder: (context) => DetailScreen(notice: notice),
      ),
    );

    if (result == true) {
      _loadNotices();
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: const Row(
          children: [
            Icon(Icons.campaign_outlined, size: 28),
            SizedBox(width: 10),
            Text(
              'College Notice Board',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            tooltip: 'Refresh Notices',
            onPressed: _loadNotices,
          ),
        ],
        elevation: 2,
      ),
      body: Column(
        children: [
          // Department Filter Chips Row
          Container(
            padding: const EdgeInsets.symmetric(vertical: 10),
            color: theme.colorScheme.surfaceContainerHighest.withValues(alpha: 0.3),
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                children: _departments.map((dept) {
                  final isSelected = _selectedDepartment == dept;
                  return Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: FilterChip(
                      label: Text(dept),
                      selected: isSelected,
                      showCheckmark: true,
                      onSelected: (selected) {
                        setState(() {
                          _selectedDepartment = dept;
                        });
                      },
                      selectedColor: theme.colorScheme.primaryContainer,
                      labelStyle: TextStyle(
                        fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                        color: isSelected
                            ? theme.colorScheme.onPrimaryContainer
                            : theme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                  );
                }).toList(),
              ),
            ),
          ),

          // Notices Count Header
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  _selectedDepartment == 'All'
                      ? 'All Announcements (${_filteredNotices.length})'
                      : '$_selectedDepartment Department (${_filteredNotices.length})',
                  style: theme.textTheme.titleSmall?.copyWith(
                    color: theme.colorScheme.onSurfaceVariant,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                if (_allNotices.isEmpty && !_isLoading)
                  TextButton.icon(
                    onPressed: () async {
                      await _storageService.resetToSamples();
                      _loadNotices();
                    },
                    icon: const Icon(Icons.restore, size: 16),
                    label: const Text('Reset Samples'),
                  ),
              ],
            ),
          ),

          // Notice list or empty/loading state
          Expanded(
            child: _isLoading
                ? const Center(child: CircularProgressIndicator())
                : _filteredNotices.isEmpty
                    ? _buildEmptyState(theme)
                    : RefreshIndicator(
                        onRefresh: _loadNotices,
                        child: ListView.builder(
                          padding: const EdgeInsets.all(12),
                          itemCount: _filteredNotices.length,
                          itemBuilder: (context, index) {
                            final notice = _filteredNotices[index];
                            final deptColor = _getDepartmentColor(notice.department);

                            return Card(
                              margin: const EdgeInsets.only(bottom: 12),
                              elevation: 1.5,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(16),
                                side: BorderSide(
                                  color: theme.colorScheme.outlineVariant.withValues(alpha: 0.5),
                                ),
                              ),
                              child: InkWell(
                                borderRadius: BorderRadius.circular(16),
                                onTap: () => _navigateToDetail(notice),
                                child: Padding(
                                  padding: const EdgeInsets.all(16),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      // Top row: Department Chip & Date
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          Container(
                                            padding: const EdgeInsets.symmetric(
                                              horizontal: 10,
                                              vertical: 4,
                                            ),
                                            decoration: BoxDecoration(
                                              color: deptColor.withValues(alpha: 0.12),
                                              borderRadius: BorderRadius.circular(20),
                                              border: Border.all(color: deptColor.withValues(alpha: 0.4), width: 1),
                                            ),
                                            child: Row(
                                              mainAxisSize: MainAxisSize.min,
                                              children: [
                                                Container(
                                                  width: 7,
                                                  height: 7,
                                                  decoration: BoxDecoration(
                                                    color: deptColor,
                                                    shape: BoxShape.circle,
                                                  ),
                                                ),
                                                const SizedBox(width: 6),
                                                Text(
                                                  notice.department,
                                                  style: TextStyle(
                                                    color: deptColor,
                                                    fontWeight: FontWeight.w700,
                                                    fontSize: 12,
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Row(
                                            children: [
                                              Icon(
                                                Icons.calendar_today_outlined,
                                                size: 13,
                                                color: theme.colorScheme.outline,
                                              ),
                                              const SizedBox(width: 4),
                                              Text(
                                                notice.formattedDate,
                                                style: theme.textTheme.bodySmall?.copyWith(
                                                  color: theme.colorScheme.outline,
                                                  fontWeight: FontWeight.w500,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ],
                                      ),
                                      const SizedBox(height: 12),

                                      // Notice Title
                                      Text(
                                        notice.title,
                                        style: theme.textTheme.titleMedium?.copyWith(
                                          fontWeight: FontWeight.bold,
                                          height: 1.25,
                                        ),
                                        maxLines: 2,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                      const SizedBox(height: 8),

                                      // Brief Description Preview
                                      Text(
                                        notice.description,
                                        style: theme.textTheme.bodyMedium?.copyWith(
                                          color: theme.colorScheme.onSurfaceVariant,
                                          height: 1.4,
                                        ),
                                        maxLines: 2,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                      const SizedBox(height: 12),

                                      // Bottom Tap hint
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.end,
                                        children: [
                                          Text(
                                            'View notice',
                                            style: TextStyle(
                                              fontSize: 12,
                                              color: theme.colorScheme.primary,
                                              fontWeight: FontWeight.w600,
                                            ),
                                          ),
                                          const SizedBox(width: 4),
                                          Icon(
                                            Icons.arrow_forward,
                                            size: 14,
                                            color: theme.colorScheme.primary,
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            );
                          },
                        ),
                      ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _navigateToAddNotice,
        icon: const Icon(Icons.add),
        label: const Text('Post Notice'),
        tooltip: 'Post Notice',
      ),
    );
  }

  /// Empty state widget displayed when no notices match the filter or list is empty
  Widget _buildEmptyState(ThemeData theme) {
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: theme.colorScheme.surfaceContainerHighest.withValues(alpha: 0.5),
                shape: BoxShape.circle,
              ),
              child: Icon(
                Icons.folder_off_outlined,
                size: 64,
                color: theme.colorScheme.outline,
              ),
            ),
            const SizedBox(height: 16),
            Text(
              'No notices found',
              style: theme.textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.bold,
                color: theme.colorScheme.onSurface,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              _selectedDepartment == 'All'
                  ? 'There are currently no college notices posted.'
                  : 'No notices posted for the $_selectedDepartment department yet.',
              textAlign: TextAlign.center,
              style: theme.textTheme.bodyMedium?.copyWith(
                color: theme.colorScheme.onSurfaceVariant,
              ),
            ),
            const SizedBox(height: 20),
            if (_selectedDepartment != 'All')
              OutlinedButton.icon(
                onPressed: () {
                  setState(() {
                    _selectedDepartment = 'All';
                  });
                },
                icon: const Icon(Icons.clear_all),
                label: const Text('Show All Departments'),
              )
            else
              FilledButton.icon(
                onPressed: _navigateToAddNotice,
                icon: const Icon(Icons.add),
                label: const Text('Post the First Notice'),
              ),
          ],
        ),
      ),
    );
  }
}