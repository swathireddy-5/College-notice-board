import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/notice.dart';

/// StorageService manages persistent local storage of notices
/// using the SharedPreferences package with JSON serialization.
class StorageService {
  static const String _noticesStorageKey = 'college_notice_board_items';
  static const String _preloadedKey = 'college_notice_board_preloaded_v1';

  /// Preloaded 6 sample notices across different college departments
  static List<Notice> getSampleNotices() {
    final now = DateTime.now();
    return [
      Notice(
        id: 'notice_1',
        title: 'Mid-Semester Examination Schedule Announced',
        description:
            'The mid-semester examination timetable for all undergraduate B.Tech courses has been released. Exams will commence from November 18, 2026. Hall tickets can be downloaded from the university portal starting Monday. Please ensure all lab clearances are completed before collecting hall tickets.',
        date: now.subtract(const Duration(days: 1)),
        department: 'Administration',
      ),
      Notice(
        id: 'notice_2',
        title: 'National Level Hackathon 2026 Registration Open',
        description:
            'The Department of Computer Science & Engineering invites student teams for "HackCampus 2026", a 36-hour hackathon focusing on AI for Sustainable Development and Cloud Architecture. Cash prizes worth $5,000 for top 3 teams. Registration deadline is November 25.',
        date: now.subtract(const Duration(days: 2)),
        department: 'CSE',
      ),
      Notice(
        id: 'notice_3',
        title: 'VLSI Chip Design & Embedded Systems Workshop',
        description:
            'A 2-day hands-on workshop on Cadence EDA tools and FPGA prototyping will be conducted by industry veterans from Intel and Texas Instruments in the Microelectronics Lab on November 20-21. Limited to 40 participants.',
        date: now.subtract(const Duration(days: 3)),
        department: 'ECE',
      ),
      Notice(
        id: 'notice_4',
        title: 'Electric Vehicle Powertrain Seminar & Demo',
        description:
            'Join the EEE department this Friday at 2:00 PM in Seminar Hall B for a lecture on Battery Management Systems (BMS) and high-efficiency permanent magnet motors, followed by a live electric kart powertrain demonstration.',
        date: now.subtract(const Duration(days: 4)),
        department: 'EEE',
      ),
      Notice(
        id: 'notice_5',
        title: 'Industrial Visit to Automotive Assembly Plant',
        description:
            'Third-year Mechanical Engineering students are eligible for the upcoming one-day technical visit to the Tata Motors Robotic Assembly Unit. Interested students must submit parental consent forms to the department office by Friday.',
        date: now.subtract(const Duration(days: 5)),
        department: 'Mechanical',
      ),
      Notice(
        id: 'notice_6',
        title: 'Smart Cities & Seismic Resilient Structures Guest Lecture',
        description:
            'Dr. Arvind Sharma from the National Disaster Management Authority will deliver a keynote speech on earthquake-resistant building design and IoT sensors in bridge monitoring. Mandatory attendance for final year Civil students.',
        date: now.subtract(const Duration(days: 6)),
        department: 'Civil',
      ),
    ];
  }

  /// Loads notices from local SharedPreferences.
  /// Automatically seeds sample notices on the very first launch.
  Future<List<Notice>> loadNotices() async {
    final prefs = await SharedPreferences.getInstance();

    final hasPreloaded = prefs.getBool(_preloadedKey) ?? false;
    if (!hasPreloaded) {
      // First launch: initialize with 6 realistic sample notices
      final samples = getSampleNotices();
      await saveNotices(samples);
      await prefs.setBool(_preloadedKey, true);
      return samples;
    }

    final rawJsonString = prefs.getString(_noticesStorageKey);
    if (rawJsonString == null || rawJsonString.trim().isEmpty) {
      return [];
    }

    try {
      final List<dynamic> decodedList = jsonDecode(rawJsonString) as List<dynamic>;
      final notices = decodedList
          .map((item) => Notice.fromJson(item as Map<String, dynamic>))
          .toList();

      // Sort notices in reverse chronological order (newest first)
      notices.sort((a, b) => b.date.compareTo(a.date));
      return notices;
    } catch (e) {
      // Fallback in case of corrupted JSON
      return [];
    }
  }

  /// Saves the complete list of notices to SharedPreferences
  Future<void> saveNotices(List<Notice> notices) async {
    final prefs = await SharedPreferences.getInstance();
    final jsonList = notices.map((n) => n.toJson()).toList();
    final jsonString = jsonEncode(jsonList);
    await prefs.setString(_noticesStorageKey, jsonString);
  }

  /// Appends a newly created notice to local storage
  Future<void> addNotice(Notice notice) async {
    final currentList = await loadNotices();
    currentList.insert(0, notice);
    await saveNotices(currentList);
  }

  /// Deletes a notice by its unique ID
  Future<void> deleteNotice(String id) async {
    final currentList = await loadNotices();
    currentList.removeWhere((item) => item.id == id);
    await saveNotices(currentList);
  }

  /// Resets storage back to default sample notices (useful for testing/demo)
  Future<List<Notice>> resetToSamples() async {
    final samples = getSampleNotices();
    await saveNotices(samples);
    return samples;
  }
}