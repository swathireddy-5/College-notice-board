import 'package:flutter/material.dart';
import 'screens/home_screen.dart';

/// Entry point of the College Notice Board application.
void main() async {
  // Ensure Flutter engine bindings are initialized before calling native plugins
  WidgetsFlutterBinding.ensureInitialized();

  runApp(const CollegeNoticeBoardApp());
}

/// The root widget configuring Material 3 theme and routing.
class CollegeNoticeBoardApp extends StatelessWidget {
  const CollegeNoticeBoardApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'College Notice Board',
      debugShowCheckedModeBanner: false,
      themeMode: ThemeMode.system,

      // Light Theme with Material 3 and deep college blue seed
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF1E3A8A), // Classic collegiate navy blue
          brightness: Brightness.light,
        ),
        appBarTheme: const AppBarTheme(
          centerTitle: false,
          elevation: 0,
        ),
        cardTheme: const CardTheme(
          clipBehavior: Clip.antiAlias,
        ),
        inputDecorationTheme: const InputDecorationTheme(
          filled: true,
        ),
      ),

      // Dark Theme with Material 3
      darkTheme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF3B82F6),
          brightness: Brightness.dark,
        ),
        appBarTheme: const AppBarTheme(
          centerTitle: false,
          elevation: 0,
        ),
        cardTheme: const CardTheme(
          clipBehavior: Clip.antiAlias,
        ),
        inputDecorationTheme: const InputDecorationTheme(
          filled: true,
        ),
      ),

      // Initial home screen
      home: const HomeScreen(),
    );
  }
}